-- Controle de ciclos VIP no admin
-- Rode este SQL no Supabase antes de usar a criação/ativação de ciclos pela tela.

alter table if exists public.vip_mini_options
  add column if not exists cycle_key text;

create index if not exists vip_mini_options_cycle_key_idx
  on public.vip_mini_options (cycle_key);

create table if not exists public.vip_cycle_control (
  id text primary key,
  active_cycle_key text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

insert into public.vip_cycle_control (id, active_cycle_key)
values ('default', null)
on conflict (id) do nothing;


alter table if exists public.profiles
  add column if not exists vip_cycle_key text;

create index if not exists profiles_vip_cycle_key_idx
  on public.profiles (vip_cycle_key);
