import React from "react";
import { supabase } from "../lib/supabaseClient";

const AuthContext = React.createContext(null);

const CHECKOUT_SESSION_BACKUP_KEY = "cc_checkout_session_backup";

function readCheckoutSessionBackup() {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(CHECKOUT_SESSION_BACKUP_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object") return null;
    const access_token = String(parsed.access_token || "").trim();
    const refresh_token = String(parsed.refresh_token || "").trim();
    if (!access_token || !refresh_token) return null;
    return {
      access_token,
      refresh_token,
      expires_at: Number(parsed.expires_at || 0) || undefined,
      expires_in: Number(parsed.expires_in || 0) || undefined,
      token_type: String(parsed.token_type || "bearer") || "bearer",
    };
  } catch {
    return null;
  }
}

function clearCheckoutSessionBackup() {
  if (typeof window === "undefined") return;
  try { window.localStorage.removeItem(CHECKOUT_SESSION_BACKUP_KEY); } catch {}
}

async function restoreCheckoutSessionBackup() {
  const backup = readCheckoutSessionBackup();
  if (!backup) return null;
  try {
    const { data, error } = await supabase.auth.setSession(backup);
    if (error) return null;
    return data?.session || null;
  } catch {
    return null;
  }
}



function hasCheckoutReturnSignals() {
  if (typeof window === "undefined") return false;
  try {
    const params = new URLSearchParams(window.location.search || "");
    return ["success", "pending", "cancel"].includes(String(params.get("payment") || "").toLowerCase());
  } catch {
    return false;
  }
}

function hasRecoverySignals() {
  if (typeof window === "undefined") return false;
  try {
    const params = new URLSearchParams(window.location.search || "");
    const hash = String(window.location.hash || "");
    const path = String(window.location.pathname || "");
    const isResetPath = path === "/redefinir-senha";
    const type = String(params.get("type") || "").toLowerCase();
    const tokenHash = String(params.get("token_hash") || "");
    const hasRecoveryType = type === "recovery" || /type=recovery/i.test(hash);
    const hasRecoveryToken = /access_token=/i.test(hash) || /refresh_token=/i.test(hash);
    const hasResetCode = isResetPath && !!params.get("code");
    return hasRecoveryType || hasRecoveryToken || !!tokenHash || hasResetCode;
  } catch {
    return false;
  }
}


function userHasPassword(user) {
  if (!user) return false;

  const metadataFlag = user?.user_metadata?.has_password;
  if (metadataFlag === true) return true;
  if (metadataFlag === false) return false;

  const providers = [];
  const directProvider = String(user?.app_metadata?.provider || '').toLowerCase().trim();
  const appProviders = Array.isArray(user?.app_metadata?.providers) ? user.app_metadata.providers : [];
  const identityProviders = Array.isArray(user?.identities)
    ? user.identities.map((i) => String(i?.provider || '').toLowerCase().trim()).filter(Boolean)
    : [];

  providers.push(
    directProvider,
    ...appProviders.map((p) => String(p || '').toLowerCase().trim()),
    ...identityProviders,
  );

  const unique = Array.from(new Set(providers.filter(Boolean)));
  if (unique.includes('email')) return true;
  if (!unique.length) return true;
  return !(unique.length === 1 && unique[0] === 'google');
}

function isGoogleOnlyUser(user) {
  if (!user) return false;
  const providers = [];
  const directProvider = String(user?.app_metadata?.provider || '').toLowerCase().trim();
  const appProviders = Array.isArray(user?.app_metadata?.providers) ? user.app_metadata.providers : [];
  const identityProviders = Array.isArray(user?.identities)
    ? user.identities.map((i) => String(i?.provider || '').toLowerCase().trim()).filter(Boolean)
    : [];
  providers.push(
    directProvider,
    ...appProviders.map((p) => String(p || '').toLowerCase().trim()),
    ...identityProviders,
  );
  const unique = Array.from(new Set(providers.filter(Boolean)));
  return unique.length === 1 && unique[0] === 'google';
}

function hasAcceptedLegalTerms(user) {
  return !!(
    user?.user_metadata?.accepted_terms === true ||
    user?.user_metadata?.accepted_privacy === true ||
    user?.user_metadata?.terms_accepted_at ||
    user?.user_metadata?.privacy_accepted_at
  );
}

export function AuthProvider({ children }) {
  const [session, setSession] = React.useState(null);
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [isPasswordRecovery, setIsPasswordRecovery] = React.useState(() => {
    if (typeof window === "undefined") return false;
    try {
      return window.sessionStorage.getItem("cc_password_recovery") === "1" || hasRecoverySignals();
    } catch {
      return hasRecoverySignals();
    }
  });
  const [needsGoogleTermsAcceptance, setNeedsGoogleTermsAcceptance] = React.useState(false);

  const evaluateGoogleTermsGate = React.useCallback(async (nextUser) => {
    if (!nextUser || !isGoogleOnlyUser(nextUser) || hasAcceptedLegalTerms(nextUser)) {
      setNeedsGoogleTermsAcceptance(false);
      return;
    }
    try {
      const { data, error } = await supabase.from("profiles").select("id").eq("id", nextUser.id).maybeSingle();
      if (!error && data?.id) {
        setNeedsGoogleTermsAcceptance(false);
        return;
      }
    } catch {}
    setNeedsGoogleTermsAcceptance(true);
  }, []);

  async function completeGoogleTermsConsent() {
    if (!user?.id) return { error: new Error("Usuário não autenticado.") };
    const now = new Date().toISOString();
    try {
      const fullName = String(user?.user_metadata?.full_name || user?.user_metadata?.name || user?.identities?.[0]?.identity_data?.full_name || "").trim();
      const { error: updErr } = await supabase.auth.updateUser({
        data: {
          ...user.user_metadata,
          accepted_terms: true,
          accepted_privacy: true,
          terms_accepted_at: now,
          privacy_accepted_at: now,
        },
      });
      if (updErr) return { error: updErr };
      const profilePayload = { id: user.id };
      if (fullName) profilePayload.full_name = fullName;
      try {
        await supabase.from("profiles").upsert(profilePayload, { onConflict: "id" });
      } catch {}
      setNeedsGoogleTermsAcceptance(false);
      return { error: null };
    } catch (error) {
      return { error };
    }
  }

  React.useEffect(() => {
    let mounted = true;

    supabase.auth.getSession().then(async ({ data }) => {
      if (!mounted) return;
      let nextSession = data.session || null;
      if (!nextSession) {
        nextSession = await restoreCheckoutSessionBackup();
      }
      setSession(nextSession || null);
      setUser(nextSession?.user || null);
      if (nextSession && hasRecoverySignals()) {
        setIsPasswordRecovery(true);
        try { window.sessionStorage.setItem("cc_password_recovery", "1"); } catch {}
      }
      await evaluateGoogleTermsGate(nextSession?.user || null);
      setLoading(false);
    });

    const { data: sub } = supabase.auth.onAuthStateChange((event, nextSession) => {
      setSession(nextSession || null);
      setUser(nextSession?.user || null);
      setLoading(false);
      evaluateGoogleTermsGate(nextSession?.user || null);

      if (event === "PASSWORD_RECOVERY") {
        setIsPasswordRecovery(true);
        try { window.sessionStorage.setItem("cc_password_recovery", "1"); } catch {}
        return;
      }

      if (event === "SIGNED_OUT") {
        setIsPasswordRecovery(false);
        setNeedsGoogleTermsAcceptance(false);
        if (!hasCheckoutReturnSignals() && !readCheckoutSessionBackup()) clearCheckoutSessionBackup();
        try { window.sessionStorage.removeItem("cc_password_recovery"); } catch {}
        return;
      }

      if (event === "SIGNED_IN" || event === "INITIAL_SESSION" || event === "USER_UPDATED" || event === "TOKEN_REFRESHED") {
        const keepRecovery = hasRecoverySignals();
        setIsPasswordRecovery(keepRecovery);
        if (nextSession?.access_token && nextSession?.refresh_token) {
          try {
            window.localStorage.setItem(
              CHECKOUT_SESSION_BACKUP_KEY,
              JSON.stringify({
                access_token: nextSession.access_token,
                refresh_token: nextSession.refresh_token,
                expires_at: nextSession.expires_at || 0,
                expires_in: nextSession.expires_in || 0,
                token_type: nextSession.token_type || 'bearer',
              })
            );
          } catch {}
        }
        try {
          if (keepRecovery) window.sessionStorage.setItem("cc_password_recovery", "1");
          else window.sessionStorage.removeItem("cc_password_recovery");
        } catch {}
      }
    });

    return () => {
      mounted = false;
      sub?.subscription?.unsubscribe?.();
    };
  }, [evaluateGoogleTermsGate]);

  async function saveProfile(userId, profile, jwt) {
    if (!userId || !profile) return { error: null };

    const payload = {
      full_name: profile.full_name,
      phone: profile.phone,
      address_line1: profile.address_line1,
      address_number: profile.address_number,
      address_line2: profile.address_line2,
      neighborhood: profile.neighborhood,
      city: profile.city,
      state: profile.state,
      zip: profile.zip,
      cpf: profile.cpf,
      birthdate: profile.birthdate,
    };

    // remove campos vazios
    Object.keys(payload).forEach((k) => {
      if (payload[k] === undefined || payload[k] === null || payload[k] === "") {
        delete payload[k];
      }
    });

    // Preferência: salvar via API (Service Role), para não depender de RLS no client.
    try {
      if (jwt) {
        const resp = await fetch("/api/profile", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${jwt}`,
          },
          body: JSON.stringify({ profile: payload }),
        });

        const data = await resp.json().catch(() => ({}));
        if (!resp.ok) {
          return {
            error: new Error(data?.error || "Não foi possível salvar seus dados."),
          };
        }
        return { error: null };
      }
    } catch (e) {
      // fallback abaixo
      console.warn("profile api failed", e);
    }

    // Fallback: tentar salvar direto pelo client (caso RLS esteja ok)
    try {
      const { error } = await supabase
        .from("profiles")
        .upsert({ id: userId, ...payload }, { onConflict: "id" });
      if (error) return { error };
      return { error: null };
    } catch (e) {
      return { error: e };
    }
  }

  async function signUp({ email, password, profile }) {
    const emailRedirectTo =
      typeof window !== "undefined" ? window.location.origin : undefined;

    // Se a confirmação por e-mail estiver habilitada no Supabase,
    // esse redirect evita links quebrados em produção.
    const resp = await supabase.auth.signUp({
      email,
      password,
      options: emailRedirectTo ? { emailRedirectTo } : undefined,
    });

    // Se a confirmação por e-mail estiver desativada, já teremos session/user.
    // Salva os dados do perfil.
    if (resp?.data?.user?.id && profile) {
      if (resp?.data?.session) {
        const saved = await saveProfile(resp.data.user.id, profile, resp.data.session.access_token);
        if (saved?.error) {
          // não bloqueia criação de conta, mas avisa no console para debug
          console.warn("profiles upsert error", saved.error);
        }
      } else {
        // Sem session (email confirmation): guarda temporariamente
        try {
          localStorage.setItem(
            "pending_profile",
            JSON.stringify({ email, profile })
          );
        } catch {
          // ignore
        }
      }
    }

    return resp;
  }

  async function signIn({ email, password }) {
    const resp = await supabase.auth.signInWithPassword({ email, password });

    // Se havia um profile pendente (signup com confirmação por e-mail), tenta salvar ao entrar
    try {
      const raw = localStorage.getItem("pending_profile");
      if (raw && resp?.data?.user?.id) {
        const parsed = JSON.parse(raw);
        if (parsed?.email === email && parsed?.profile) {
          const saved = await saveProfile(resp.data.user.id, parsed.profile, resp.data.session.access_token);
          if (saved?.error) console.warn("profiles upsert error", saved.error);
          localStorage.removeItem("pending_profile");
        }
      }
    } catch {
      // ignore
    }

    return resp;
  }

  async function resetPassword({ email }) {
    const redirectTo =
      typeof window !== "undefined" ? `${window.location.origin}/redefinir-senha` : undefined;
    return supabase.auth.resetPasswordForEmail(email, redirectTo ? { redirectTo } : undefined);
  }

  function clearPasswordRecovery() {
    setIsPasswordRecovery(false);
    try { if (typeof window !== "undefined") window.sessionStorage.removeItem("cc_password_recovery"); } catch {}
  }

  async function signOut() {
    return supabase.auth.signOut();
  }

  async function signInWithGoogle() {
    const redirectTo = typeof window !== "undefined" ? window.location.origin : undefined;
    setIsPasswordRecovery(false);
    try { if (typeof window !== "undefined") window.sessionStorage.removeItem("cc_password_recovery"); } catch {}
    return supabase.auth.signInWithOAuth({
      provider: "google",
      options: redirectTo ? { redirectTo } : undefined,
    });
  }

  const accountHasPassword = React.useMemo(() => userHasPassword(user), [user]);

  const value = React.useMemo(
    () => ({ session, user, loading, signUp, signIn, signInWithGoogle, resetPassword, signOut, isPasswordRecovery, clearPasswordRecovery, accountHasPassword, needsGoogleTermsAcceptance, completeGoogleTermsConsent }),
    [session, user, loading, isPasswordRecovery, accountHasPassword, needsGoogleTermsAcceptance]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = React.useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
